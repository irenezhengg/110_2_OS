#Team members:
#資工三 方文昊 108590048
#資工三 鄭琳玲 108590056
#資工三 黃聖耀 108590061
#電資三 李以謙 108820021

import time
import threading

pCnt = 5
rCnt = 3

fin = []
theAlloc = []
seqnc = []

theMax = []
avb = []
theNeed = []


class theThreads(threading.Thread):

    def __init__(self, theIdx, lock):
    
        threading.Thread.__init__(self)
        
        self.theIdx = theIdx
        self.lock = lock

    def run(self):
    
        while(fin[self.theIdx] == False):
        
            equalOrLess = True
            
            for i in range(rCnt):
            
                self.lock.acquire()
                strs = "After the comparison with P" + str(self.theIdx) + "'s allocation, therefore, the available is "

                for i in range(rCnt):
                    strs = strs + str(avb[i]) + " "
                print(strs)

                if theNeed[self.theIdx][i] > avb[i]:
                    equalOrLess = False

                self.lock.release()

            if equalOrLess:
            
                self.lock.acquire()
                strs = "\nAfter the comparison with P" + str(self.theIdx) + "'s allocation, therefore, the new available is "

                for i in range(rCnt):
                    avb[i] = avb[i] + theAlloc[self.theIdx][i]
                    strs = strs + str(avb[i]) + " "

                print(strs + "\n")
                
                seqnc.append(self.theIdx)
                self.lock.release()
                
                fin[self.theIdx] = True

def main():

    threads = []
    lock = threading.Lock()
    
    rCnt = int(input("Input number of resources: "))
    pCnt = int(input("Input number of processes: "))

    for i in range(pCnt):
        items = []
        inp_tp = input("Input allocation of P" + str(i) + ": ")
        inp_tp = inp_tp.split()

        for j in range(rCnt):
            items.append(int(inp_tp[j]))
        theAlloc.append(items)

    for i in range(pCnt):
        items = []
        inp_tp = input("Input maximum of P" + str(i) + ": ")
        inp_tp = inp_tp.split()

        for j in range(rCnt):
            items.append(int(inp_tp[j]))
        theMax.append(items)

    inp_tp = input("Input the available: ")
    inp_tp = inp_tp.split()

    for i in range(rCnt):
        avb.append(int(inp_tp[i]))

    for i in range(pCnt):
        items = []
        fin.append(False)

        for j in range(rCnt):
            items.append(theMax[i][j] - theAlloc[i][j])
        theNeed.append(items)

    print("\nAllocation:\n")

    for i in range(pCnt):
    
        print("P" + str(i), end = " ")

        for j in range(rCnt):
            print(theAlloc[i][j], end = " ")
        print("")

    print("\nMaximum:\n")

    for i in range(pCnt):
        print("P" + str(i), end = " ")

        for j in range(rCnt):
            print(theMax[i][j], end = " ")
        print("")

    print("\nNeed:\n")

    for i in range(pCnt):
        print("P" + str(i), end = " ")

        for j in range(rCnt):
            print(theNeed[i][j], end = " ")
        print("")

    print("\nAvailable: ", end = " ")

    for i in range(rCnt):
        print(avb[i], end = " ")
    print("\n")

    for i in range(pCnt):
        threads.append(theThreads(i, lock))
        threads[i].start()

    for i in range(pCnt):
        threads[i].join()

    print("The sequence of safe-state is", end = " ")

    for x in seqnc:
        ax = "P" + str(x)
        print(ax, end = " ")
    print("")

main()
