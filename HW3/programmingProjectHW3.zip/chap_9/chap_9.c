/*
Team members:
資工三 方文昊 108590048
資工三 鄭琳玲 108590056
資工三 黃聖耀 108590061
電資三 李以謙 108820021
*/

#include <unistd.h>
#include <pthread.h>
#include <assert.h>

#include <string.h>

#include <stdio.h>
#include <stdlib.h>

#define SIZE_OF_THE_PAGE 256
#define SIZE_OF_THE_FRAME 256

#define SIZE_OF_THE_TLB 16

#define SIZE_OF_THE_PHYSICAL_MEMORY SIZE_OF_THE_PAGE * SIZE_OF_THE_FRAME

int addr_lgc = 0, addr_physc = 0;
int osNum = 0, pNum = 0;

int theFrame = 0;
int val = 0, rec = 0;

int idxTLB = 0, sizeOfTLB = 0, cntTLB = 0;
int cntAddr = 0, cntF = 0;

float rateOfTLB = 0, rateF = 0;

unsigned mask_os = 255; 

unsigned mask_pNum = 65280; 

struct tableOfTLB {

	unsigned int numbersOfPage;

	unsigned int numbersOfFrame;
	
};

int main (int argc, char *argv[]){
	if (argc != 2) {
		fprintf(stderr, "Please input the input file name (e.g. ./chap_9 <inputFileName.txt>) \n");
		exit(1);
	}

	FILE *the_address = fopen(argv[1],"r");
	FILE *BACKINGSTORE = fopen("BACKING_STORE.bin", "rb");

	FILE *file_output = fopen("addresses_outputResult.txt", "w");

	int mem_physc[SIZE_OF_THE_PHYSICAL_MEMORY];
    	int Idx;
    
	char theBuffer[256];

	int pageOfTable[SIZE_OF_THE_PAGE];
	
	memset(pageOfTable, -1, 256*sizeof(int));

	struct tableOfTLB tlb[SIZE_OF_THE_TLB];
	
	memset (pageOfTable, -1, 16*sizeof(char));

	while(fscanf(the_address, "%d", &addr_lgc) == 1){
		cntAddr++;

		pNum = addr_lgc & mask_pNum;
		pNum = pNum >> 8;

		osNum = addr_lgc & mask_os;
		rec = -1;

		for(Idx = 0; Idx < sizeOfTLB; Idx++) {

			if(tlb[Idx].numbersOfPage == pNum) {

				rec = tlb[Idx].numbersOfFrame;
				addr_physc = rec * 256 + osNum;
			}
		}

		if(!(rec == -1)){cntTLB++;}
		
		else if(pageOfTable[pNum] == -1){

			fseek(BACKINGSTORE, pNum * 256, SEEK_SET);
			fread(theBuffer, sizeof(char), 256, BACKINGSTORE);

			pageOfTable[pNum] = theFrame;

			for(Idx = 0; Idx < 256; Idx++){mem_physc[theFrame * 256 + Idx] = theBuffer[Idx];}

			cntF++;

			theFrame++;
\
			if(sizeOfTLB == 16){sizeOfTLB--;}

			for(idxTLB = sizeOfTLB; idxTLB > 0; idxTLB--) {

				tlb[idxTLB].numbersOfPage = tlb[idxTLB - 1].numbersOfPage;
				tlb[idxTLB].numbersOfFrame = tlb[idxTLB - 1].numbersOfFrame;
			}

			if (sizeOfTLB <= 15){sizeOfTLB++;}

			tlb[0].numbersOfPage = pNum;
			tlb[0].numbersOfFrame = pageOfTable[pNum];

			addr_physc = pageOfTable[pNum] * 256 + osNum;

		} 

        	else {addr_physc = pageOfTable[pNum] * 256 + osNum;}

		val = mem_physc[addr_physc];

		fprintf(file_output, "The virtual address: %d, The physical address: %d, The value: %d \n", addr_lgc, addr_physc, val);
	}

    rateF = cntF * 1.0f / cntAddr;
    rateOfTLB = cntTLB * 1.0f / cntAddr;

    fclose(the_address);
    fclose(BACKINGSTORE);

    fprintf(file_output, "The number of the addresses is %d\n", cntAddr);

    fprintf(file_output, "The Number of the page fault is %d\n", cntF);

    fprintf(file_output, "The rate of the page fault is %f\n", rateF);

    fprintf(file_output, "The number of Hits of TLB is %d\n", cntTLB);

    fprintf(file_output, "The hit rate of TLB is %f\n", rateOfTLB);

    fclose(file_output);
    return 0;
}
